class SurveyController < ApplicationController
    def index
    end
end
